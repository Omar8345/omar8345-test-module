from __future__ import annotations

__all__ = ["hello"]

def hello() -> str:
  return "Hello from the cleanup test package!"
